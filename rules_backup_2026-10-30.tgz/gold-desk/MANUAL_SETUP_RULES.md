# Standing rule: setups on request (trader, 26 Oct 2026 00:4x UTC)

Applies whenever Woody asks for a setup (chat, a SCAN tap, Crown, or a forwarded message).

1. **Send it straight to Telegram.** Never ask "want me to send it?" first.
2. **Actionable now only:** a market entry at the live price, or a limit within about 1 x 15m ATR (about $3-5)
   of the live price. Expiry 1-2 hours, never 4.
3. **Stamp every setup** with the live price and the London time it was made, and a line
   "⛔ Skip if price is beyond <level>" (the point where the setup is stale: past TP1, or past the entry by 0.25R).
   Always read the live mark price right before sending, not only closed candles.
4. **No good entry right now -> say so plainly**, give the exact trigger, and start a watcher that sends the setup to
   Telegram the moment it triggers (re-checking the live price at that moment).
5. A forwarded old setup is not a request to re-send it: check whether it is still valid and say so.
6. Manual setups are labelled "SETUP ON REQUEST", logged on the dashboard trades (id M-...), and tracked like desk trades.
7. **Analyse the chart properly first** (trader, 26 Oct 06:2x UTC): before any setup, do a top-down read of Daily, 4H, 1H and 15M
   (trend, EMA20/50, RSI, structure: highs/lows, breaks), key levels (prior-day H/L, VWAP, round numbers, swing points), session timing
   and news. Trade with the 4H trend unless there is a clear reversal signal. Enter on a retest of a level, not by chasing a breakout into
   nearby support/resistance. Only send a setup with at least 3 confluences, and put the short analysis and confluence list in the message.
   If the timeframes conflict, say so and wait.
8. **London time** (trader, 26 Oct 06:2x): Woody lives in London. Every time in a setup or update (made at, cancel by, events) is London time, labelled 'London' (GMT in winter, BST in summer; use /home/user/gold-desk/ldn.py).
9. **Entries that actually fill** (trader, 26 Oct 06:3x: "most of the limit orders never get filled"; 7 of 14 limits never filled,
   and in 6 of those 7 price went to TP1 without us). Choose the entry like this:
   - Confirmation candle already closed, stop behind structure is at most $10 from live price, and at least 1R of room to the next
     support/resistance -> **ENTER NOW at market**.
   - Otherwise a limit, but **no more than $3 (about 0.5 x 15M ATR) from live price**. A level further away is a WATCH alert
     ("if price reaches X and a 15M candle rejects it, I'll send it"), with a watcher that sends the setup when it happens.
   - If price reaches TP1 before the fill, the order is cancelled and Telegram says "MISSED, NOT CHASING" (quick scans do this).
10. **Pending orders never block confirmed setups** (trader, 26 Oct 07:0x): only a filled trade counts as the one open trade. When the desk sends a confirmed (VALID) setup, any order still waiting to fill is cancelled, and the same Telegram message says to delete it in MT5.
11. **Lessons from 26 Oct losses (tighten only; L-32 to L-36 on the dashboard)**:
   - **Stops:** beyond the swing or round level by max($1.50, 0.3 x 15M ATR) plus the broker offset; never within $1.50 of an obvious high/low.
   - **Ranges:** if 1H is MIXED and the range is narrower than 2 x 1H ATR, no mid-range entries; only edge rejections, or wait.
     Range position is a required confluence.
   - **No flip-flopping:** no opposite-direction setup within 60 min unless a 15M close breaks the last setup's invalidation.
   - **Expiry:** manual limits last 60 min max; orders still waiting at the London (07:00) or New York (13:30 London) open are re-checked
     at the open: confirm they are still valid or cancel them on Telegram.
   - **Broker gap:** until the trader's MT5 quote is known, add $1 extra to every SL and say levels are on the desk feed. When known,
     apply the offset (risk.json "brokerOffset") to every entry, SL and TP.
12. **Every Telegram message ends with "⚠️ Manage Risk Properly"** (trader, 26 Oct 08:4x): setups, trade updates, alerts and reports.
13. **Never trade against the 1H trend (L-38, 26 Oct strategy review):** all 4 losses were sells into a 1H making higher highs and
    higher lows. No SELL while the 1H is HH/HL, no BUY while it is LH/LL; if the 1H is MIXED, price must be on the trade's side of
    the 1H EMA21. A stale 4H label never overrides the 1H. Applies to manual setups and every scan.
14. **Aurora-KAMA trend filter (L-39, trader's order 26 Oct):** KAMA(close, 10, 2, 30) on the 1H and 4H; UP/DOWN when it rose/fell on
    each of the last 3 closed bars, else FLAT. No BUY while either is DOWN, no SELL while either is UP. The KAMA never opens trades
    by itself (as a standalone strategy it lost on gold).
15. **Strategies deleted (L-40, trader's order 26 Oct):** Trend Breakout and Sweep Reversal are no longer used, for manual setups or
    scans (weakest in the 7 Sep-23 Oct backtest: PF 1.01 and 0.73). Active: Trend Pullback, Mean Reversion, Liquidity Sweep Retest.
16. **Market orders only (trader, 26 Oct 16:10):** a manual setup is given ONLY as ENTER NOW at market, at the live price, with SL/TP from
    that price (stop still within $10). No watch alerts, no limit/stop or "wait for a dip" setups. If no strategy qualifies right now,
    say plainly "No trade right now" and why; the scans send ENTER NOW automatically when one fires.
17. **Freshness window 15 minutes (trader, 26 Oct 16:2x):** a signal can be sent up to 15 minutes after its 15m bar closed (was 8),
    because scans often run late. The no-chase rule is unchanged: never send if price has moved more than 0.25R from the signal close.
18. **Session trading only (trader, 26 Oct 17:4x):** new trades only 07:00-10:00 (London open) and 13:30-16:00 (New York open)
    London time, for manual setups and every scan. Outside those hours say "No trade: outside the trading sessions". Open trades are
    still managed (TP/SL/breakeven alerts) at any hour. Backtest 11 Sep-26 Oct: sessions +$35.47 over 28 trades; other hours -$72.61 over 79.
19. **No pending orders at all (trader, 26 Oct 17:5x):** the desk never sends or keeps a limit/stop order. Every trade is ENTER NOW at
    market. A WATCH setup is not an order: it only says what must happen before the desk sends a market entry. Older limit wording
    in rules 9-11 is retired.
20. **Precision chart read before sending (L-44, trader 26 Oct 18:0x):** before any setup is sent, check the 15m chart: a Trend Pullback or
    Liquidity Sweep Retest entry must be within 1.5 x 15m ATR of the 15m EMA20 (not stretched). Replay 11 Sep-26 Oct in sessions: 28 trades
    +$35.47 PF 1.05 -> 19 trades +$59.13 PF 1.78, both halves positive. Candle-quality and 1R-room checks were tested and not adopted.
21. **Chat answers are market orders or nothing (trader, 30 Oct 12:5x London, after a sell limit at 3973.66 never filled while price fell
    to 3955):** when Woody asks for a setup, answer with ONE of two things only: an ENTER NOW market order at the live price (entry, SL, TPs,
    lot, risk, skip-if level), or "No trade right now" plus why. Never give a "wait for a bounce to X", "sell at X-Y zone", limit or trigger
    level that could be placed as a pending order. If a market entry breaks a desk rule (session, stretch), say which rule in one line and still
    give it as a market order only if Woody asks for one anyway. Rules 16 and 19 already said this; the 30 Oct 12:29 chat answer broke them.
