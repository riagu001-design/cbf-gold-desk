SCAN button rule (trader, 22 Oct 13:30 UTC): every SCAN REQUEST runs a fresh chart check for new setups
in BOTH directions (BUY and SELL), even if a scheduled scan finished minutes ago. Only skip if a scan is
running at that moment, or the request is >5 min old when it arrives. Reply in the SCAN thread with the result.
