#!/usr/bin/env python3
"""CBF FX gold desk - QUICK SCAN for the dashboard SCAN button (about 10-30 seconds).

One script, no agents: pulls live xyz:GOLD candles straight from Hyperliquid, reads the chart with plain
maths (trend, structure, zones, ATR, RSI, VWAP), scores all 8 strategies with the rules in
agents/gold-strategy-signal.md, and picks one best setup (VALID = ENTER NOW, else WATCH with its trigger).
It never sends or places anything: the caller decides what to do with quick_scan.json.

  python3 quick_scan.py          -> writes /home/user/gold-desk/quick_scan.json and prints a summary
"""
import datetime as dt
import json
import os
import time

import requests

DESK = '/home/user/gold-desk'
COIN = 'xyz:GOLD'
API = 'https://api.hyperliquid.xyz/info'
NOW = dt.datetime.now(dt.timezone.utc)
FRESH_MIN = 15         # L-13, widened to 15 by the trader 26 Oct (scans run late); the 0.25R no-chase rule still applies
VALID_MIN = 65          # VALID needs this score (trader, 24 Oct: 75 -> 65)
SWEEP_PROBATION = 65   # trader's choice 24 Oct: one 65 threshold for every strategy (backtested 6.1 trades/day)


def candles(interval, days):
    start = int((time.time() - days * 86400) * 1000)
    r = requests.post(API, json={'type': 'candleSnapshot', 'req': {'coin': COIN, 'interval': interval, 'startTime': start}}, timeout=15)
    r.raise_for_status()
    bars = [dict(t=b['t'], T=b['T'], o=float(b['o']), h=float(b['h']), l=float(b['l']), c=float(b['c']), v=float(b['v'])) for b in r.json()]
    now_ms = time.time() * 1000
    return [b for b in bars if b['T'] < now_ms]  # closed bars only


def mark():
    r = requests.post(API, json={'type': 'metaAndAssetCtxs', 'dex': 'xyz'}, timeout=15)
    r.raise_for_status()
    meta, ctxs = r.json()
    for u, c in zip(meta['universe'], ctxs):
        if u['name'] == COIN:
            return float(c['markPx'])
    return None


def ema(xs, n):
    k, out = 2 / (n + 1), [xs[0]]
    for x in xs[1:]:
        out.append(x * k + out[-1] * (1 - k))
    return out


def atr(bars, n=14):
    tr = [bars[0]['h'] - bars[0]['l']] + [max(b['h'] - b['l'], abs(b['h'] - p['c']), abs(b['l'] - p['c'])) for p, b in zip(bars, bars[1:])]
    out = [sum(tr[:n]) / n]
    for x in tr[n:]:
        out.append((out[-1] * (n - 1) + x) / n)
    return [None] * (n - 1) + out


def rsi(closes, n=14):
    g = [max(b - a, 0) for a, b in zip(closes, closes[1:])]
    l = [max(a - b, 0) for a, b in zip(closes, closes[1:])]
    ag, al = sum(g[:n]) / n, sum(l[:n]) / n
    out = [None] * n
    for gi, li in zip(g[n:], l[n:]):
        ag, al = (ag * (n - 1) + gi) / n, (al * (n - 1) + li) / n
        out.append(100 - 100 / (1 + ag / al) if al else 100)
    return [None] + out


def swings(bars, k=2):
    hi, lo = [], []
    for i in range(k, len(bars) - k):
        w = bars[i - k:i + k + 1]
        if bars[i]['h'] == max(b['h'] for b in w):
            hi.append((bars[i]['t'], bars[i]['h']))
        if bars[i]['l'] == min(b['l'] for b in w):
            lo.append((bars[i]['t'], bars[i]['l']))
    return hi, lo


def r2(x):
    return None if x is None else round(x, 2)


def utc(ms):
    return dt.datetime.fromtimestamp(ms / 1000, dt.timezone.utc)


# ---------- data ----------
m15, h1, h4, d1 = candles('15m', 5), candles('1h', 12), candles('4h', 40), candles('1d', 10)
live = mark()
risk = json.load(open(f'{DESK}/risk.json'))
macro = json.load(open(f'{DESK}/macro.json')) if os.path.exists(f'{DESK}/macro.json') else {}

c15 = [b['c'] for b in m15]
e20, e50 = ema(c15, 20), ema(c15, 50)
a15 = atr(m15)
atr15 = a15[-1]
pct15 = round(100 * sum(1 for x in a15[-300:] if x is not None and x <= atr15) / len([x for x in a15[-300:] if x is not None]))
rsi15 = rsi(c15)
atr1h = atr(h1)[-1]
e21h = ema([b['c'] for b in h1], 21)[-1]
c4 = [b['c'] for b in h4]


def kama(xs, n=10, fast=2, slow=30):
    """Kaufman adaptive MA, the trader's Aurora-KAMA settings (close, 10, 2, 30)."""
    fs, ss = 2 / (fast + 1), 2 / (slow + 1)
    out = [None] * len(xs)
    for i in range(n, len(xs)):
        vol = sum(abs(xs[j] - xs[j - 1]) for j in range(i - n + 1, i + 1))
        sc = ((abs(xs[i] - xs[i - n]) / vol if vol else 0) * (fs - ss) + ss) ** 2
        prev = out[i - 1] if out[i - 1] is not None else xs[i - 1]
        out[i] = prev + sc * (xs[i] - prev)
    return out


def kama_dir(bars, persist=3):
    # UP / DOWN when KAMA rose / fell on each of the last 3 closed bars (Aurora rising/falling persistence 3), else FLAT
    k = kama([b['c'] for b in bars])
    if all(k[-1 - j] > k[-2 - j] for j in range(persist)):
        return 'UP'
    if all(k[-1 - j] < k[-2 - j] for j in range(persist)):
        return 'DOWN'
    return 'FLAT'


kama1h, kama4h = kama_dir(h1), kama_dir(h4)
e20_4, e50_4 = ema(c4, 20)[-1], ema(c4, 50)[-1]

today = NOW.date()
tbars = [b for b in m15 if utc(b['t']).date() == today]
pv = sum((b['h'] + b['l'] + b['c']) / 3 * b['v'] for b in tbars)
vv = sum(b['v'] for b in tbars)
vwap = pv / vv if vv else None
prev_day = [b for b in d1 if utc(b['t']).date() < today][-1]
day_hi = max(b['h'] for b in tbars) if tbars else None
day_lo = min(b['l'] for b in tbars) if tbars else None

# 4h bias and 1h structure
sh4, sl4 = swings(h4)
if c4[-1] < e20_4 < e50_4 and len(sh4) >= 2 and sh4[-1][1] < sh4[-2][1]:
    bias4 = 'BEARISH'
elif c4[-1] > e20_4 > e50_4 and len(sl4) >= 2 and sl4[-1][1] > sl4[-2][1]:
    bias4 = 'BULLISH'
else:
    bias4 = 'RANGE'
sh1, sl1 = swings(h1)
if len(sh1) >= 2 and len(sl1) >= 2 and sh1[-1][1] < sh1[-2][1] and sl1[-1][1] < sl1[-2][1]:
    struct1 = 'LH/LL'
elif len(sh1) >= 2 and len(sl1) >= 2 and sh1[-1][1] > sh1[-2][1] and sl1[-1][1] > sl1[-2][1]:
    struct1 = 'HH/HL'
else:
    struct1 = 'MIXED'

# key zones (merged within 0.3 x 1h ATR)
lv = [(prev_day['h'], 'prior-day high'), (prev_day['l'], 'prior-day low'), (e21h, '1h EMA21')]
lv += [(day_hi, 'today high'), (day_lo, 'today low')] if tbars else []
lv += [(vwap, 'VWAP')] if vwap else []
lv += [(p, '1h swing high') for _, p in sh1[-4:]] + [(p, '1h swing low') for _, p in sl1[-4:]]
base = round(c15[-1] / 25) * 25
lv += [(base + k * 25, 'round $25') for k in (-2, -1, 0, 1, 2)]
lv.sort()
zones = []
for p, why in lv:
    if zones and p - zones[-1]['high'] <= 0.3 * atr1h:
        z = zones[-1]
        z['high'] = max(z['high'], p)
        z['why'] = z['why'] if why in z['why'] else f"{z['why']}, {why}"
    else:
        zones.append({'low': p, 'high': p, 'why': why})
for z in zones:
    z['low'], z['high'] = r2(z['low']), r2(z['high'])
price = c15[-1]
above = [z for z in zones if z['low'] > price][:3]
below = [z for z in reversed(zones) if z['high'] < price][:3]
key_hit = lambda lo, hi: [z for z in zones if z['low'] - 0.25 * atr15 <= hi and z['high'] + 0.25 * atr15 >= lo]

# ---------- strategies ----------
bar, prev = m15[-1], m15[-2]
bar_close_at = utc(bar['T'] + 1)
age_min = (NOW - bar_close_at).total_seconds() / 60
rng = bar['h'] - bar['l'] or 1e-9
pos = (bar['c'] - bar['l']) / rng  # 0 = closed at low, 1 = at high
cap = risk['balance'] * risk['maxRiskPct'] / 100
news = (macro.get('newsBias') or 'neutral').lower()


def room(side, entry, R):
    opp = [z['low'] for z in zones if z['low'] > entry + 0.1] if side == 'BUY' else [z['high'] for z in zones if z['high'] < entry - 0.1]
    if not opp or R <= 0:
        return 10
    d = (min(opp) - entry) if side == 'BUY' else (entry - max(opp))
    return 10 if d >= 1.5 * R else 5 if d >= R else 0


def std_score(side, fired, entry, stop, zone_ok):
    R = abs(entry - stop)
    s = 10 if bias4 == 'RANGE' else 20 if bias4 == ('BULLISH' if side == 'BUY' else 'BEARISH') else 0
    s += 20 if struct1 == ('HH/HL' if side == 'BUY' else 'LH/LL') else 0
    s += 20 if zone_ok else 0
    s += 10 if fired and (pos >= 2 / 3 if side == 'BUY' else pos <= 1 / 3) else 0
    s += room(side, entry, R)
    s += 5 if news in ('neutral', 'unknown', '') else 10 if news == ('positive' if side == 'BUY' else 'negative') else 0
    s += 5 if (rsi15[-1] < 70 if side == 'BUY' else rsi15[-1] > 30) else 0
    s += 5 if 25 <= pct15 <= 90 else 0
    return s


def setup(strategy, side, fired, entry, stop, score, why, missing):
    R = abs(entry - stop)
    sgn = 1 if side == 'BUY' else -1
    return dict(strategy=strategy, side=side, fired=fired, score=score, entry=r2(entry), stop=r2(stop),
                tp1=r2(entry + sgn * 0.5 * R), tp2=r2(entry + sgn * R), tp3=r2(entry + sgn * 1.5 * R), R=r2(R), why=why, missing=missing)


out = []
for side in ('BUY', 'SELL'):
    sg = 1 if side == 'BUY' else -1
    up = e20[-1] > e50[-1] if side == 'BUY' else e20[-1] < e50[-1]
    # Trend Pullback
    near = abs((bar['l'] if side == 'BUY' else bar['h']) - e20[-1]) <= 0.25 * atr15 or bool(key_hit(bar['l'], bar['h']))
    closed_ok = bar['c'] > e20[-1] and bar['c'] > bar['o'] if side == 'BUY' else bar['c'] < e20[-1] and bar['c'] < bar['o']
    fired = up and near and closed_ok
    ext = bar['l'] if side == 'BUY' else bar['h']
    if fired:
        entry, pb_why = bar['c'], f'EMA20 {e20[-1]:.2f}'
    else:  # WATCH: the pullback level on the correct side of price (EMA20, or the nearest zone if price is already past it)
        ok_e20 = e20[-1] < price if side == 'BUY' else e20[-1] > price
        if ok_e20:
            entry, pb_why = e20[-1], f'EMA20 {e20[-1]:.2f}'
        else:
            zs = below if side == 'BUY' else above
            entry, pb_why = (zs[0]['high'], f"{zs[0]['why']} {zs[0]['high']:.2f}") if side == 'BUY' and zs else \
                            (zs[0]['low'], f"{zs[0]['why']} {zs[0]['low']:.2f}") if zs else (e20[-1], f'EMA20 {e20[-1]:.2f}')
    stop = ext - sg * 0.5 * atr15 if fired else entry - sg * 1.0 * atr15
    out.append(setup('Trend Pullback', side, fired, entry, stop, std_score(side, fired, entry, stop, near if fired else True),
                     f'15m trend {"aligned" if up else "against"} ({"EMA20 over EMA50" if e20[-1] > e50[-1] else "EMA20 under EMA50"}), pullback to {pb_why}',
                     None if fired else f'a 15m candle closes {"bullish" if side == "BUY" else "bearish"} at the {pb_why}; then ENTER NOW at market'))
    # Trend Breakout
    look = m15[-5:-1]
    lvl = max(b['h'] for b in look) if side == 'BUY' else min(b['l'] for b in look)
    fired = up and (bar['c'] > lvl if side == 'BUY' else bar['c'] < lvl)
    entry = bar['c'] if fired else lvl + sg * 0.1
    stop = entry - sg * max(atr15, abs(entry - lvl) + 0.25 * atr15)
    out.append(setup('Trend Breakout', side, fired, entry, stop, std_score(side, fired, entry, stop, bool(key_hit(lvl, lvl))),
                     f'4-bar {"high" if side == "BUY" else "low"} {lvl:.2f}, 15m trend {"aligned" if up else "not aligned"}',
                     None if fired else f'a 15m close {"above" if side == "BUY" else "below"} {lvl:.2f} with EMA20 {"above" if side == "BUY" else "below"} EMA50'))
    # Mean Reversion
    if vwap:
        ext_lvl = vwap - sg * 1.5 * atr1h
        hit = (bar['l'] <= ext_lvl or bar['l'] <= prev_day['l']) if side == 'BUY' else (bar['h'] >= ext_lvl or bar['h'] >= prev_day['h'])
        half = pos >= 0.5 if side == 'BUY' else pos <= 0.5
        allowed = bias4 == 'RANGE' or bool(key_hit(bar['l'], bar['h']))
        fired = hit and half and allowed
        entry = bar['c'] if fired else ext_lvl
        stop = (bar['l'] if side == 'BUY' else bar['h']) - sg * 0.5 * atr15 if fired else entry - sg * 1.0 * atr15
        out.append(setup('Mean Reversion', side, fired, entry, stop, std_score(side, fired, entry, stop, hit),
                         f'VWAP {vwap:.2f}, stretch level {ext_lvl:.2f}',
                         None if fired else f'a 15m {"low" if side == "BUY" else "high"} at {ext_lvl:.2f} that closes back in the {"upper" if side == "BUY" else "lower"} half'))
    # Sweep Reversal (sweep bar = prev, reclaim prev or bar... confirmation = latest closed bar)
    best_sw = None
    vol_avg = sum(b['v'] for b in m15[-23:-3]) / 20
    for sw_i in (-3, -2):
        sw = m15[sw_i]
        keys = [z for z in zones if (z['low'] if side == 'BUY' else z['high']) and
                (sw['l'] < z['low'] if side == 'BUY' else sw['h'] > z['high'])]
        for z in keys:
            level = z['low'] if side == 'BUY' else z['high']
            depth = (level - sw['l']) if side == 'BUY' else (sw['h'] - level)
            if not 0.3 * atr15 <= depth <= 2.0 * atr15:
                continue
            rec = [b for b in m15[sw_i:-1]][:2]
            rec_ok = [b for b in rec if (b['c'] > level if side == 'BUY' else b['c'] < level)]
            if not rec_ok:
                continue
            rb = rec_ok[0]
            rpos = (rb['c'] - rb['l']) / ((rb['h'] - rb['l']) or 1e-9)
            top = rpos >= 2 / 3 if side == 'BUY' else rpos <= 1 / 3
            vol = max(sw['v'], rb['v']) / vol_avg if vol_avg else 0
            ext = sw['l'] if side == 'BUY' else sw['h']
            conf = (bar['l'] > ext and bar['c'] > level) if side == 'BUY' else (bar['h'] < ext and bar['c'] < level)
            fired = top and vol >= 1.5 and conf
            sc = (20 if 'round' not in z['why'] or ',' in z['why'] else 10)
            sc += 15 if depth <= 1.5 * atr15 else 5
            sc += 15 if top else 0
            sc += 10 if vol >= 1.5 else 5 if vol >= 1.2 else 0
            sc += 10 if conf and (bar['c'] > bar['o'] if side == 'BUY' else bar['c'] < bar['o']) else 0
            entry = bar['c'] if fired else level + sg * 0.25 * atr15
            stop = ext - sg * 0.3 * atr15
            sc += room(side, entry, abs(entry - stop))
            sc += 5 if bias4 == 'RANGE' else 10 if bias4 == ('BULLISH' if side == 'BUY' else 'BEARISH') else 0
            sc += 0 if news == ('negative' if side == 'BUY' else 'positive') else 5
            sw_rsi = rsi15[len(m15) + sw_i]
            sc += 5 if sw_rsi and (sw_rsi < 35 if side == 'BUY' else sw_rsi > 65) else 0
            cand = setup('Sweep Reversal', side, fired, entry, stop, sc,
                         f'swept {z["why"]} {level:.2f} by {depth:.1f}, reclaimed, volume {vol:.1f}x',
                         None if fired else f'a 15m close holding {"above" if side == "BUY" else "below"} {level:.2f} near {entry:.2f}; then ENTER NOW at market')
            if not best_sw or cand['score'] > best_sw['score']:
                best_sw = cand
    if best_sw:
        out.append(best_sw)


# Liquidity Sweep Retest (trader's request, 23 Oct; backtested 1 Sep-23 Oct 15m: 15 trades, PF 2.6 with desk exits).
# Prior-day or Asian high/low swept and closed back inside, a minor 15m swing broken the other way, entry on the
# retest of that swing; stop beyond the sweep, target the next meaningful level (at least 1R away).
def lsr_setup():
    def minor(j, hi):
        for x in range(j - 2, max(2, j - 12), -1):
            nb = [m15[y][hi and 'h' or 'l'] for y in range(x - 2, x + 3) if y != x and y < j]
            v = m15[x]['h' if hi else 'l']
            if nb and (v >= max(nb) if hi else v <= min(nb)):
                return v
        return None
    asian = [b for b in tbars if utc(b['t']).hour < 6]
    lvls = [('H', prev_day['h'], 'prior-day high'), ('L', prev_day['l'], 'prior-day low')]
    if asian:
        lvls += [('H', max(b['h'] for b in asian), 'Asian high'), ('L', min(b['l'] for b in asian), 'Asian low')]
    targets = [prev_day['h'], prev_day['l']] + [p for _, p in sh1[-6:]] + [p for _, p in sl1[-6:]] + [L for _, L, _ in lvls]
    n = len(m15) - 1
    found = None
    for i in range(max(30, n - 20), n + 1):
        sb = m15[i]
        if utc(sb['t']).date() != today or utc(sb['t']).hour < 6:
            continue
        for kind, L, name in lvls:
            if kind == 'H' and sb['h'] > L > sb['c']:
                side, ext, mn = 'SELL', sb['h'], minor(i, False)
            elif kind == 'L' and sb['l'] < L < sb['c']:
                side, ext, mn = 'BUY', sb['l'], minor(i, True)
            else:
                continue
            if mn is None:
                continue
            brk = None
            for j in range(i + 1, min(i + 7, n + 1)):
                bj = m15[j]
                if (side == 'SELL' and bj['h'] > ext) or (side == 'BUY' and bj['l'] < ext):
                    break
                if (side == 'SELL' and bj['c'] < mn) or (side == 'BUY' and bj['c'] > mn):
                    brk = j
                    break
            if brk is None:
                continue
            state = 'armed' if brk == n else None
            for k in range(brk + 1, min(brk + 7, n + 1)):
                bk = m15[k]
                if (side == 'SELL' and bk['h'] > ext) or (side == 'BUY' and bk['l'] < ext):
                    state = None
                    break
                if (side == 'SELL' and bk['h'] >= mn) or (side == 'BUY' and bk['l'] <= mn):
                    state = 'fired' if k == n else None
                    break
                state = 'armed' if k == n else None
            if state:
                found = (side, ext, mn, name, L, state, i)
    if not found:
        return None
    side, ext, mn, name, L, state, i = found
    sg = 1 if side == 'BUY' else -1
    stop = ext - sg * 0.1 * atr15
    R = abs(mn - stop)
    if R < 0.5:
        return None
    tg = sorted((p for p in targets if sg * (p - mn) >= R), key=lambda p: sg * (p - mn))
    if not tg:
        return None
    s = setup('Liquidity Sweep Retest', side, state == 'fired', mn, stop, 85,
              f'swept {name} {L:.2f} at {utc(m15[i]["t"]):%H:%M}, closed back inside, broke the 15m swing {mn:.2f}',
              None if state == 'fired' else f'a 15m close on a retest of {mn:.2f} while {ext:.2f} holds; then ENTER NOW at market')
    s['tp3'] = r2(tg[0])
    return s


lsr = lsr_setup()
if lsr:
    out.append(lsr)

# trader's order 26 Oct: delete the weakest strategies. Backtest 7 Sep-23 Oct (VALID only): Sweep Reversal PF 0.73 (-1.8R),
# Trend Breakout PF 1.01 (0R, -5R in the second half, 2 of the 4 live losses). They are no longer scored or sent.
REMOVED = ('Sweep Reversal', 'Trend Breakout')
out = [s for s in out if s['strategy'] not in REMOVED]

# ---------- decide ----------
in_hours = NOW.weekday() < 5 and risk['sessionsUTC'][0] <= NOW.hour < risk['sessionsUTC'][1]  # weekdays only: spot gold is shut at weekends
# trader's order 26 Oct (rule 18): new trades only in the London session 07:00-10:00 and the New York session 13:30-16:00 London time.
# Backtest 11 Sep-26 Oct: those hours +$35.47 over 28 trades, all other hours -$72.61 over 79.
from zoneinfo import ZoneInfo
_l = NOW.astimezone(ZoneInfo('Europe/London'))
_m = _l.hour * 60 + _l.minute
in_session = 7 * 60 <= _m < 10 * 60 or 13 * 60 + 30 <= _m < 16 * 60
blackout = bool(macro.get('blackout'))
for w in macro.get('windows', []):
    try:
        t = dt.datetime.fromisoformat(w['timeUTC'].replace('Z', '+00:00'))
        if t - dt.timedelta(minutes=30) <= NOW <= t + dt.timedelta(minutes=15):
            blackout = True
    except (KeyError, ValueError):
        pass
live_gap = abs(live - price) if live else 0
for s in out:
    need = SWEEP_PROBATION if s['strategy'] in ('Sweep Reversal', 'Liquidity Sweep Retest') else VALID_MIN
    blocks = []
    if not s['fired']:
        blocks.append('entry rule has not fired')
    if s['score'] < need:
        blocks.append(f'score under {need}')
    if s['R'] > cap:
        blocks.append(f'stop too wide (R {s["R"]} > cap {cap:.0f})')
    if age_min > FRESH_MIN:
        blocks.append(f'signal bar closed {age_min:.0f} min ago')
    if not in_hours:
        blocks.append(f'outside desk hours {risk["sessionsUTC"]} UTC')
    if not in_session:
        blocks.append('outside trading sessions (07:00-10:00 and 13:30-16:00 London)')
    if blackout:
        blocks.append('news blackout')
    # lesson L-38 (26 Oct): every loss so far was a trade against the 1h trend; never fight the 1h structure
    against = 'LH/LL' if s['side'] == 'BUY' else 'HH/HL'
    if struct1 == against:
        blocks.append(f'against the 1h trend ({struct1})')
    # trader's order 26 Oct: Aurora-KAMA direction is a trend filter; no trade against the 1h or 4h KAMA
    for tf, kd in (('1h', kama1h), ('4h', kama4h)):
        if kd == ('DOWN' if s['side'] == 'BUY' else 'UP'):
            blocks.append(f'against the {tf} KAMA ({kd})')
    if struct1 == 'MIXED' and ((s['side'] == 'BUY' and price < e21h) or (s['side'] == 'SELL' and price > e21h)):
        blocks.append(f"1h mixed and price on the wrong side of the 1h EMA21 {r2(e21h)}")
    if live and s['fired'] and live_gap > 0.25 * s['R']:
        blocks.append(f'price already moved {live_gap:.1f} from the signal close')
    # precision chart read (trader, 26 Oct 18:0x; L-44): never enter a trend trade stretched more than 1.5 x 15m ATR from the EMA20.
    # Replay 11 Sep-26 Oct, sessions: 28 trades +$35.47 PF 1.05 -> 19 trades +$59.13 PF 1.78, both halves positive.
    # Candle-quality and 1R-room checks were tested too and NOT adopted (they cut good trades: +$42.85 unstable / +$21.87).
    if s['fired'] and s['strategy'] != 'Mean Reversion' and abs(s['entry'] - e20[-1]) > 1.5 * atr15:
        blocks.append(f'precision: stretched {abs(s["entry"] - e20[-1]):.1f} from the 15m EMA20 (over 1.5 ATR)')
    s['status'] = 'VALID' if not blocks else 'WATCH'
    s['blocks'] = blocks
# a setup the trend filters forbid (L-38/L-39) is never shown as the best while a with-trend one exists
trend_blocked = lambda s: any(x.startswith('against the') or x.startswith('1h mixed') for x in s['blocks'])
out.sort(key=lambda s: (s['status'] == 'VALID', not trend_blocked(s), s['score'], s['fired']), reverse=True)
best = out[0]

res = dict(asOf=NOW.isoformat(timespec='seconds').replace('+00:00', 'Z'), mode='quick',
           live=live, lastBar=dict(at=bar_close_at.strftime('%H:%M'), o=bar['o'], h=bar['h'], l=bar['l'], c=bar['c'], ageMin=round(age_min, 1)),
           staleCheck=f'live {live} vs last close {price} (gap {live_gap:.1f}, ATR15 {atr15:.2f})' + (' - price moved over 1 ATR since the close' if live_gap > atr15 else ''),
           bias4h=bias4, structure1h=struct1, kama1h=kama1h, kama4h=kama4h, atr15=r2(atr15), atrPct15=pct15, atr1h=r2(atr1h), rsi15=r2(rsi15[-1]),
           ema20_15=r2(e20[-1]), ema50_15=r2(e50[-1]), vwap=r2(vwap), ema21_1h=r2(e21h),
           prevDay=dict(h=prev_day['h'], l=prev_day['l']), today=dict(h=day_hi, l=day_lo),
           zonesAbove=above, zonesBelow=below, news=news, blackout=blackout, inHours=in_hours,
           best=best, ratings=[{k: s[k] for k in ('strategy', 'side', 'score', 'fired', 'status')} for s in out])
json.dump(res, open(f'{DESK}/quick_scan.json', 'w'), indent=1)

print(f"QUICK SCAN {res['asOf']} | live {live} | last 15m {res['lastBar']['at']} close {price} ({age_min:.0f} min ago)")
print(f"4h {bias4} | 1h {struct1} | KAMA 1h {kama1h} 4h {kama4h} | ATR15 {atr15:.2f} (p{pct15}) | RSI15 {rsi15[-1]:.1f} | VWAP {r2(vwap)} | EMA20/50 {e20[-1]:.2f}/{e50[-1]:.2f}")
print('Above:', ', '.join(f"{z['low']} {z['why']}" for z in above), '| Below:', ', '.join(f"{z['high']} {z['why']}" for z in below))
b = best
print(f"BEST {b['status']} {b['side']} {b['strategy']} entry {b['entry']} SL {b['stop']} TP {b['tp1']}/{b['tp2']}/{b['tp3']} (R {b['R']})")
print('  why:', b['why'], '| missing:', b['missing'] or '-', '| blocks:', '; '.join(b['blocks']) or 'none')
