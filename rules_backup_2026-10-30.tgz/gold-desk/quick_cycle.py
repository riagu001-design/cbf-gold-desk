#!/usr/bin/env python3
"""CBF FX gold desk - one QUICK CYCLE (every 5 min, about 10 seconds of work).

  python3 quick_cycle.py <dashboard scanner.json in> <scanner.json out>

1. Runs quick_scan.py (chart read + best setup).
2. Replays every Pending/Open trade on native xyz:GOLD 5m bars since it was sent: fill, TP1 (stop to entry),
   TP2 (stop to TP1), TP3, stop loss, breakeven, expiry. Only a status CHANGE produces a Telegram alert.
3. If no trade is filled (an order still waiting to fill does not block; it is cancelled and replaced), sends the best setup once, but only when it is VALID (ENTER NOW at market); WATCH setups are not sent (trader, 24 Oct). Inside desk
   hours, outside news blackouts, risk within the cap, and not a near-copy of one sent in the last 2 hours.
4. Writes the updated dashboard rows and, if anything needs sending, /home/user/gold-desk/quick_msg.txt.
It never places broker orders. Same-bar ambiguity is scored against us (stop first).
"""
import datetime as dt
import json
import os
import subprocess
import sys

import requests

sys.path.insert(0, '/home/user/gold-desk')
from ldn import hm as lhm, utc_hm  # the trader's London time

DESK = '/home/user/gold-desk'
MSG = f'{DESK}/quick_msg.txt'
ACTIVE = ('Pending', 'Open', 'TP1 hit', 'TP2 hit')
NOW = dt.datetime.now(dt.timezone.utc)
iso = lambda t: t.strftime('%Y-%m-%dT%H:%M:%SZ')


def parse(s):
    return dt.datetime.fromisoformat(s.replace('Z', '+00:00')) if s else None


def bars_since(start):
    ms = int((start - dt.timedelta(minutes=5)).timestamp() * 1000)
    r = requests.post('https://api.hyperliquid.xyz/info', timeout=15,
                      json={'type': 'candleSnapshot', 'req': {'coin': 'xyz:GOLD', 'interval': '5m', 'startTime': ms}})
    r.raise_for_status()
    now_ms = NOW.timestamp() * 1000
    return [dict(t=dt.datetime.fromtimestamp(b['t'] / 1000, dt.timezone.utc), o=float(b['o']), h=float(b['h']),
                 l=float(b['l']), c=float(b['c'])) for b in r.json() if b['T'] < now_ms]


def replay(t):
    """Status of a trade from its levels and the bars since it was sent: (status, events, R)."""
    sent = parse(t.get('sent') or t.get('at'))
    exp = parse(t.get('last'))
    if str(t.get('id', '')).startswith('M-') and sent:  # lesson L-34 (26 Oct): manual limits wait 60 min at most
        exp = min(exp, sent + dt.timedelta(minutes=60)) if exp else sent + dt.timedelta(minutes=60)
    sell = t['side'] == 'SELL'
    e, sl, tps = t['entry'], t['stop'], [t['tp1'], t['tp2'], t['tp3']]
    bars = [b for b in bars_since(sent) if b['t'] + dt.timedelta(minutes=5) > sent]
    if not bars:
        return t['status'], [], None
    # a limit/stop order that filled later carries 'fill@' in r: replay its fill too, so TPs before the fill are not counted
    filled = t['status'] in ('Open', 'TP1 hit', 'TP2 hit') and 'fill@' not in (t.get('r') or '')
    # order type from where price was when it went out: entry below price = stop for a sell, limit for a buy
    is_stop = (bars[0]['o'] > e) if sell else (bars[0]['o'] < e)
    events, hit = [], 0
    stop = sl
    for b in bars:
        hhmm = b['t'].strftime('%H:%M')
        if not filled:
            if exp and b['t'] >= exp:
                return 'Cancelled', events + [('cancel', hhmm)], None
            touched = (b['l'] <= e if is_stop else b['h'] >= e) if sell else (b['h'] >= e if is_stop else b['l'] <= e)
            if not touched:
                # trader, 26 Oct: the move went without us. TP1 reached before the fill -> cancel, never let a stale order fill later
                if (b['l'] <= tps[0]) if sell else (b['h'] >= tps[0]):
                    return 'Cancelled', events + [('missed', hhmm)], None
                continue
            filled = True
            events.append(('fill', hhmm))
        adverse = b['h'] >= stop if sell else b['l'] <= stop
        if adverse:  # stop first when a bar touches both
            if hit == 0:
                return 'SL hit', events + [('sl', hhmm)], -1.0
            return ('Breakeven' if hit == 1 else 'Closed at TP1 trail'), events + [('be' if hit == 1 else 'trail', hhmm)], (0.0 if hit == 1 else 0.5)
        while hit < 3 and ((b['l'] <= tps[hit]) if sell else (b['h'] >= tps[hit])):
            hit += 1
            events.append((f'tp{hit}', hhmm))
            stop = e if hit == 1 else tps[0] if hit == 2 else stop
        if hit == 3:
            return 'TP3 hit', events, 1.5
    status = {0: 'Open', 1: 'TP1 hit', 2: 'TP2 hit'}[hit] if filled else 'Pending'
    return status, events, None


def alert(t, events, result):
    icon = '🔴' if t['side'] == 'SELL' else '🟢'
    lines = []
    for kind, hhmm in events:
        hhmm = utc_hm(hhmm)  # shown in London time
        if kind == 'fill':
            lines.append(f"✅ FILLED: {icon} {t['side']} XAUUSD @ {t['entry']:.2f} ({hhmm} London)")
        elif kind.startswith('tp'):
            n = kind[2]
            extra = {'1': f"👉 Move SL to entry {t['entry']:.2f}", '2': f"👉 Trail runner SL to TP1 {t['tp1']:.2f}", '3': '🏆 ALL TARGETS HIT ✅✅✅ Close any remaining position.'}[n]
            lines.append(f"🎯 TP{n} HIT ✅ {t[f'tp{n}']:.2f} ({hhmm} London)\n{extra}")
        elif kind == 'sl':
            lines.append(f"🛑 STOP LOSS HIT: {t['stop']:.2f} ({hhmm} London)")
        elif kind == 'be':
            lines.append(f"⚖️ BREAKEVEN: stopped at entry {t['entry']:.2f} after TP1 ({hhmm} London)")
        elif kind == 'trail':
            lines.append(f"🔒 Runner stopped at TP1 {t['tp1']:.2f} after TP2 ({hhmm} London)")
        elif kind == 'missed':
            lines.append(f"❌ MISSED, NOT CHASING: price reached TP1 {t['tp1']:.2f} without filling {t['side']} @ {t['entry']:.2f} ({hhmm} London). Delete the order in MT5.")
        elif kind == 'cancel':
            lines.append(f"❌ ORDER CANCELLED: {t['side']} @ {t['entry']:.2f} not filled by expiry. Remove it from MT5.")
    if result is not None:
        lines.append(f"Result: {result:+.1f}R")
    return '👑 CBF FX | TRADE UPDATE\n' + '\n'.join(lines)


def main(src, dst):
    subprocess.run([sys.executable, f'{DESK}/quick_scan.py'], check=True, capture_output=True)
    q = json.load(open(f'{DESK}/quick_scan.json'))
    b = q['best']
    rows = json.load(open(src))
    risk = json.load(open(f'{DESK}/risk.json'))
    cap = risk['balance'] * risk['maxRiskPct'] / 100
    msgs, pm_note, ex_note, ex_status = [], 'No active trades', 'Nothing new to send', 'Skipped'

    # 2. manage active trades
    trades = [r for r in rows if r['kind'] == 'trade']
    for t in trades:
        if t.get('status') not in ACTIVE:
            continue
        before = t['status']
        status, events, result = replay(t)
        seen = t.get('r') if isinstance(t.get('r'), str) else ''
        new_events = [ev for ev in events if f'{ev[0]}@{ev[1]}' not in seen]
        if status != before or new_events:
            t['status'] = status
            t['r'] = ';'.join(f'{k}@{h}' for k, h in events) or None
            if new_events:
                msgs.append(alert(t, new_events, result))
            pm_note = f"{t['side']} {t['entry']}: {before} -> {status}"
        else:
            pm_note = f"{t['side']} {t['entry']}: {status}, no change"

    # 3. send the best setup once
    # trader, 26 Oct: an order still waiting to fill must not block a confirmed (VALID) setup; only a filled trade blocks
    active = [t for t in trades if t.get('status') in ('Open', 'TP1 hit', 'TP2 hit')]
    pending = [t for t in trades if t.get('status') == 'Pending']
    in_hours = q['inHours'] and not q['blackout']
    recent = [t for t in trades if t.get('sent') and parse(t['sent']) > NOW - dt.timedelta(hours=2)]
    near_copy = any(t['side'] == b['side'] and t.get('strategy') == b['strategy'] and abs(t['entry'] - b['entry']) < 0.5 * (b['R'] or 1) for t in recent)
    # daily loss limit (risk.json dailyLossPct of balance): losing trades sent today at 0.01 lot
    today = NOW.date().isoformat()
    lost = sum(abs(t['entry'] - t['stop']) for t in trades
               if t.get('status') == 'SL hit' and str(t.get('sent') or t.get('at') or '')[:10] == today)
    day_cap = risk['balance'] * risk['dailyLossPct'] / 100
    if day_cap and lost >= day_cap:
        ex_note = f"Daily loss limit hit (-${lost:.2f} of ${day_cap:.0f}); no new trades today"
    elif active:
        ex_note = f"Blocked: {active[0]['side']} {active[0]['entry']} is {active[0]['status']}"
    elif not in_hours:
        ex_note = 'Outside desk hours or news blackout'
    elif b['status'] != 'VALID':
        # trader's decision 24 Oct after the full backtest: unconfirmed WATCH setups lost -21R as limit/stop orders
        ex_note = f"Best is WATCH, not sent (confirmed setups only): {b['missing'] or '; '.join(b.get('blocks') or [])}"[:90]
    elif not b['R'] or b['R'] > cap:
        ex_note = f"Best setup stop too wide (R {b['R']} > {cap:.0f})"
    elif near_copy:
        ex_note = 'Best setup already sent in the last 2h'
    elif any(t.get('status') == 'SL hit' and t.get('side') == b['side'] and t.get('strategy') == b['strategy']
             and parse(t.get('sent') or t.get('at')) > NOW - dt.timedelta(hours=3) for t in trades):
        # lesson L-37 (26 Oct): no re-entry with the same strategy and side within 3h of its stop-out
        ex_note = f"{b['strategy']} {b['side']} stopped out in the last 3h; not re-sent"
    else:
        icon = '🔴' if b['side'] == 'SELL' else '🟢'
        live = q['live'] or b['entry']
        exp = min(NOW + dt.timedelta(hours=4), NOW.replace(hour=20, minute=45, second=0))
        for w in json.load(open(f'{DESK}/macro.json')).get('windows', []) if os.path.exists(f'{DESK}/macro.json') else []:
            bs = parse(w.get('blackoutStart') or '')
            if bs and NOW < bs < exp:
                exp = bs
        # trader, 26 Oct 17:5x: market orders only, never a pending limit/stop order (only VALID setups reach here)
        otype, title = 'MARKET', '⚡ ENTER NOW · MARKET ✅'
        head = f"⏱️ Enter now, valid until {lhm(NOW + dt.timedelta(minutes=15))} London; skip if price is beyond {b['entry'] + (0.25 * b['R'] if b['side'] == 'BUY' else -0.25 * b['R']):.2f}"
        text = (f"👑 CBF FX | {title}\n{icon} XAUUSD {otype if otype != 'MARKET' else b['side']} @ {b['entry']:.2f}\n"
                f"Strategy: {b['strategy']} (M15)\n" + (head + '\n' if head else '') +
                f"\n🛑 Stop Loss: {b['stop']:.2f}\n🎯 TP1 (0.5R): {b['tp1']:.2f}  (SL to Entry)\n🎯 TP2 (1.0R): {b['tp2']:.2f}\n🎯 TP3 (Runner): {b['tp3']:.2f}\n"
                f"Lot: 0.01 (risk ≈ ${b['R']:.2f})\n\n" + (f"⏳ Awaiting: {b['missing']}\n" if b['missing'] else '') +
                f"✅ Reason: {b['why']}\n⌛ Cancel if not filled by {lhm(exp)} London")
        sg = 1 if b['side'] == 'SELL' else -1  # lesson L-35: the trader's MT5 can quote a few dollars off the desk feed
        text += (f"\n📡 Levels are on the desk feed (your MT5 may differ). Use the same distances from your MT5 entry: "
                 f"SL {'+' if sg > 0 else '−'}${abs(b['stop'] - b['entry']):.2f} · TP1 {'−' if sg > 0 else '+'}${abs(b['entry'] - b['tp1']):.2f} · "
                 f"TP2 {'−' if sg > 0 else '+'}${abs(b['entry'] - b['tp2']):.2f} · TP3 {'−' if sg > 0 else '+'}${abs(b['entry'] - b['tp3']):.2f}")
        for t in pending:  # replaced by the confirmed setup: cancel it and tell the trader to delete it
            t['status'] = 'Cancelled'
            t['r'] = ';'.join(x for x in [t.get('r') if isinstance(t.get('r'), str) else '', f"replaced@{NOW:%H:%M}"] if x)
            text += f"\n\n❌ Delete your {t['side']} order @ {t['entry']:.2f} in MT5: replaced by this confirmed setup (one trade at a time)."
        msgs.append(text)
        rows.append(dict(kind='trade', id=f"Q-{b['strategy']}-{b['side']}-{round(b['entry'])}", at=iso(NOW), sent=iso(NOW), side=b['side'],
                         strategy=b['strategy'], rating=None, note=f"Quick scan {otype}: {b['missing'] or 'enter now'}", entry=b['entry'], stop=b['stop'],
                         tp1=b['tp1'], tp2=b['tp2'], tp3=b['tp3'], status='Open', r=None, last=iso(exp)))
        ex_note, ex_status = f"Sent {otype if otype != 'MARKET' else b['side'] + ' MARKET'} {b['entry']:.2f}", 'Sent'

    # 4. dashboard rows
    for r in rows:
        if r['kind'] == 'best':
            r.update(at=q['asOf'], strategy=b['strategy'], side=b['side'], status=b['status'], entry=b['entry'], stop=b['stop'],
                     tp1=b['tp1'], tp2=b['tp2'], tp3=b['tp3'], note=b['why'][:110], last=('ready to ENTER NOW at market' if b['status'] == 'VALID' else 'No order: ' + (b['missing'] or '; '.join(b.get('blocks') or [])))[:200])
        if r['kind'] == 'agent':
            upd = {'Market Data': ('OK', f"Quick {q['asOf'][11:16]}: live {q['live']}, 15m close {q['lastBar']['c']}"),
                   'Technical Analysis': ('OK', f"Quick: 4h {q['bias4h']}, 1h {q['structure1h']}, KAMA 1h/4h {q.get('kama1h')}/{q.get('kama4h')}, ATR15 {q['atr15']}, RSI {q['rsi15']}"),
                   'Strategy / Signal': ('OK', f"Quick: {b['status']} {b['side']} {b['strategy']} @ {b['entry']}"),
                   'Position Manager': ('Sent' if msgs and pm_note != 'No active trades' else 'OK', pm_note),
                   'Execution': (ex_status, ex_note)}.get(r['strategy'])
            if upd:
                r.update(at=q['asOf'], status=upd[0], last=upd[1][:90])
        if r['kind'] == 'level':
            key = 'zonesAbove' if r['id'].startswith('R') else 'zonesBelow'
            i = int(r['id'][1]) - 1
            if i < len(q[key]):
                z = q[key][i]
                r.update(at=q['asOf'], entry=z['low'], stop=z['high'], note=z['why'][:70])
    json.dump(rows, open(dst, 'w'), indent=1)
    if msgs:
        open(MSG, 'w').write('\n\n'.join(msgs) + '\n\n⚠️ Manage Risk Properly')  # trader, 26 Oct: on every Telegram message
    elif os.path.exists(MSG):
        os.remove(MSG)
    print(json.dumps(dict(best=f"{b['status']} {b['side']} {b['strategy']} {b['entry']}", pm=pm_note, execution=ex_note, telegram=bool(msgs))))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
