#!/usr/bin/env python3
"""Set up a fresh session for one quick cycle.

  python3 quick_boot.py <quick_kit.json> <dashboard scanner.json>

Writes the kit's scripts and risk.json into /home/user/gold-desk, and builds macro.json from the dashboard's
own news rows (event rows = high-impact windows, driver D0 = news bias), so blackouts follow the latest full scan.
"""
import json
import os
import re
import sys

DESK = '/home/user/gold-desk'
os.makedirs(DESK, exist_ok=True)
kit = json.load(open(sys.argv[1]))
for name, text in kit['files'].items():
    with open(os.path.join(DESK, name), 'w') as f:
        f.write(text)

rows = json.load(open(sys.argv[2]))
windows = [{'event': r.get('strategy'), 'timeUTC': r.get('note'), 'blackoutStart': r.get('last')}
           for r in rows if r.get('kind') == 'event' and r.get('note')]
d0 = next((r for r in rows if r.get('kind') == 'driver' and r.get('id') == 'D0'), {})
m = re.search(r'bias:\s*([A-Za-z]+)', d0.get('note') or '')
macro = {'newsBias': (m.group(1).lower() if m else 'neutral'), 'blackout': 'BLACKOUT NOW' in (d0.get('note') or ''), 'windows': windows}
json.dump(macro, open(os.path.join(DESK, 'macro.json'), 'w'), indent=1)
print(f"kit ready: {', '.join(kit['files'])}; {len(windows)} news windows; bias {macro['newsBias']}")
